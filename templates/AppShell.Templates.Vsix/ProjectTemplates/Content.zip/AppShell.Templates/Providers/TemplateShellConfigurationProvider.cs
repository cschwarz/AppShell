﻿using AppShell;

namespace $safeprojectname$
{
    public class $ext_shellname$ShellConfigurationProvider : ShellConfigurationProvider
    {
        public $ext_shellname$ShellConfigurationProvider()
        {
            RegisterShellViewModel<StackShellViewModel>();
        }
    }
}
