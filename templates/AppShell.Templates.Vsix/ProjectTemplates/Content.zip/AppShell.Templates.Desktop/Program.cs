﻿using System;

namespace $safeprojectname$
{
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            $ext_shellname$App app = new $ext_shellname$App();
            app.Run();
        }
    }
}
