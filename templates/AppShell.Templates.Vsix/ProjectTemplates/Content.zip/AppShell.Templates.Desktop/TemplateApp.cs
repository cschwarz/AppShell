﻿using AppShell.Desktop;

namespace $safeprojectname$
{
    public class $ext_shellname$App : ShellApplication<$ext_shellname$AppShellCore>
    {
    }
}
